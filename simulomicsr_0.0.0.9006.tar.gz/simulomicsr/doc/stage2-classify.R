## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----setup, eval = FALSE------------------------------------------------------
# library(simulomicsr)
# library(jsonlite)
# 
# facts_list <- fromJSON(
#   system.file("extdata/stage2-fixtures-mini/GSE145941-sample-facts.json",
#               package = "simulomicsr"),
#   simplifyVector = FALSE
# )
# study_summary <- fromJSON(
#   system.file("extdata/stage2-fixtures-mini/GSE145941-study-summary.json",
#               package = "simulomicsr"),
#   simplifyVector = FALSE
# )
# cache <- cache_init(tempfile(), namespace = "stage2-vignette")

## ----classify, eval = FALSE---------------------------------------------------
# design <- classify_study(
#   series_id = "GSE145941",
#   sample_facts_list = facts_list,
#   study_summary = study_summary,
#   provider = "openai", model = "gpt-5.5",
#   cache = cache
# )
# str(design, max.level = 2)

## ----anchor, eval = FALSE-----------------------------------------------------
# treated_facts <- facts_list[[1]]  # uno dei sample irradiati
# anchor <- make_anchor(treated_facts, stage2_role = "perturbed")
# anchor

## ----inducer, eval = FALSE----------------------------------------------------
# make_inducer_log(treated_facts)  # vuoto se nessun mediated_effect

