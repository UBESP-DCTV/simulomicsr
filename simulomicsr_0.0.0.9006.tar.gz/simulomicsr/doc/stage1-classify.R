## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(simulomicsr)

## -----------------------------------------------------------------------------
# Fixture stabile bundled nel pacchetto (8 sample dal xlsx)
fix <- simulomicsr:::read_sample_fixtures_mini()
row <- fix[fix$stratum == "easy_treated", , drop = FALSE][1, ]
str(as.list(row))

## -----------------------------------------------------------------------------
fake_response <- jsonlite::fromJSON(
  readr::read_file(system.file(
    "schemas/sample_facts.stage1.v3.json", package = "simulomicsr"
  )),
  simplifyVector = FALSE
)
# (in un caso reale, useremmo provider="openai" — vedi sotto)

## ----eval=FALSE---------------------------------------------------------------
# # Esempio reale (richiede OPENAI_API_KEY in .Renviron.local)
# res <- classify_sample(
#   sample_string = row$string,
#   geo_accession = row$geo_accession,
#   series_id     = row$series_id,
#   provider = "openai",
#   model    = "gpt-5.5"
# )
# str(res$value, max.level = 2)

## ----eval=FALSE---------------------------------------------------------------
# cache <- cache_init(tempfile(), namespace = "stage1")
# 
# r1 <- classify_sample(
#   sample_string = row$string,
#   geo_accession = row$geo_accession,
#   series_id     = row$series_id,
#   cache         = cache
# )
# r1$cache_hit  # FALSE — prima chiamata
# 
# r2 <- classify_sample(
#   sample_string = row$string,
#   geo_accession = row$geo_accession,
#   series_id     = row$series_id,
#   cache         = cache
# )
# r2$cache_hit  # TRUE — risposta servita dalla cache

