## ----setup, include = FALSE---------------------------------------------------
# Tutti i chunk sono `eval = FALSE` perche' richiederebbero una chiave
# OPENAI_API_KEY valida e/o file di lookup non disponibili in fase di
# build del pacchetto. La vignette serve come manuale d'uso.
knitr::opts_chunk$set(
  collapse = TRUE,
  comment  = "#>",
  eval     = FALSE
)

